import random
import mysql.connector

conexion = mysql.connector.connect(
    host="localhost",
    user="progra_aplicada",
    password="1234567890",
    database="IoT"
)

cursor = conexion.cursor()

nombre = "Scooter-" + str(random.randint(1,3))
bateria = random.randint(10,100)
kilometraje = round(random.uniform(10,150),2)

lugares = [
    "Plaza de Armas",
    "Mall Plaza Chillán",
    "Campus INACAP",
    "Terminal",
    "Hospital"
]

ubicacion = random.choice(lugares)

sql = """
INSERT INTO scooters(nombre,bateria,kilometraje,ubicacion)
VALUES(%s,%s,%s,%s)
"""

cursor.execute(sql,(nombre,bateria,kilometraje,ubicacion))

conexion.commit()

cursor.close()
conexion.close()